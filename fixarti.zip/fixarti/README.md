# Fixarti — Master Manga & Digital Art

Flutter MVP: Canvas | Academy | Critic | Community.

## بناء ملف APK (بدون كمبيوتر، من الموبايل أو أي جهاز)

1. أنشئ حساب على github.com (مجاني) ثم مستودع جديد باسم `fixarti`.
2. ارفع محتويات هذا المجلد كلها (بما فيها المجلد المخفي `.github`) إلى المستودع.
3. افتح تبويب **Actions** ← **Build Fixarti APK** ← **Run workflow**.
4. بعد 5–10 دقائق افتح التشغيل الناجح ونزّل **fixarti-apk** من قسم Artifacts، ثم فك الضغط وثبّت `app-release.apk`.

## البناء محليًا
```
flutter create . --platforms=android --project-name fixarti --org com.fixarti
flutter pub get
flutter run                 # تجربة على جهاز
flutter build apk --release # بناء APK
```

## الهيكل
```
lib/
  main.dart, app_shell.dart        # الثيم الداكن + شريط التنقل (4 تبويبات)
  canvas/
    models.dart                    # فرش، ضربات، طبقات
    canvas_controller.dart         # الطبقات، undo/redo، الإرشادات، التصدير
    canvas_view.dart               # اللمس: رسم / تكبير / تدوير / نقرة بإصبعين = تراجع
    painters.dart                  # رسم الفرش والطبقات والمنظور
    canvas_screen.dart, layer_sheet.dart
  academy/   pose_dummy.dart, academy_screen.dart
  critic/    critic_service.dart, critic_screen.dart   # مساعد اختياري
  community/ community_screen.dart
```

## ملاحظات
- المساعد الذكي اختياري ولا يرسل شيئًا إلا عند الضغط على الزر. مفتاح الـ API يُدخل يدويًا؛ للنشر العام مرّر الطلبات عبر خادم خاص بك.
- تصدير الفيديو (time-lapse) غير مضمَّن في هذه النسخة، المتوفر حاليًا تصدير PNG.
- مكتبة المراجع حاليًا نصية (نصائح)، ويمكنك تحميل صورك كمرجع فوق اللوحة.
