import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../canvas/canvas_controller.dart';

const _prompts = <String>[
  'A cat wearing a samurai helmet',
  'Your hand holding a cup, 3 angles',
  'Rainy street in one-point perspective',
  'Character jumping with a strong line of action',
  'Eyes: happy, angry, sleepy, surprised',
  'Hair blowing in the wind',
  'A robot reading a book',
  'Screen-tone sunset over the sea',
  'Two friends sharing an umbrella',
  'A dragon curled around a tower',
];

String todaysPrompt() {
  final now = DateTime.now();
  final dayOfYear = now.difference(DateTime(now.year, 1, 1)).inDays;
  return _prompts[dayOfYear % _prompts.length];
}

class CommunityScreen extends StatelessWidget {
  const CommunityScreen(
      {super.key, required this.controller, required this.onOpenCanvas});
  final CanvasController controller;
  final VoidCallback onOpenCanvas;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(children: [
        const TabBar(tabs: [
          Tab(icon: Icon(Icons.emoji_events_outlined), text: 'Challenge Hub'),
          Tab(icon: Icon(Icons.photo_library_outlined), text: 'My Gallery'),
        ]),
        Expanded(
          child: TabBarView(children: [
            _Challenges(controller: controller, onOpenCanvas: onOpenCanvas),
            const _Gallery(),
          ]),
        ),
      ]),
    );
  }
}

class _Challenges extends StatelessWidget {
  const _Challenges({required this.controller, required this.onOpenCanvas});
  final CanvasController controller;
  final VoidCallback onOpenCanvas;

  void _start(String prompt) {
    controller.newCanvas(prompt: prompt);
    onOpenCanvas();
  }

  @override
  Widget build(BuildContext context) {
    final today = todaysPrompt();
    return ListView(padding: const EdgeInsets.all(12), children: [
      Card(
        color: const Color(0xFF3B2A6B),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text("TODAY'S CHALLENGE",
                style: TextStyle(letterSpacing: 1.2, fontSize: 12)),
            const SizedBox(height: 8),
            Text(today, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            FilledButton.icon(
              icon: const Icon(Icons.brush),
              label: const Text('Start drawing'),
              onPressed: () => _start(today),
            ),
          ]),
        ),
      ),
      const Padding(
        padding: EdgeInsets.fromLTRB(4, 16, 4, 4),
        child: Text('More prompts'),
      ),
      for (final p in _prompts)
        Card(
          child: ListTile(
            title: Text(p),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _start(p),
          ),
        ),
    ]);
  }
}

class _Gallery extends StatefulWidget {
  const _Gallery();

  @override
  State<_Gallery> createState() => _GalleryState();
}

class _GalleryState extends State<_Gallery> {
  late Future<List<File>> _files = _load();

  Future<List<File>> _load() async {
    final dir = await getApplicationDocumentsDirectory();
    final g = Directory('${dir.path}/fixarti_gallery');
    if (!await g.exists()) return [];
    final files = g
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.png'))
        .toList()
      ..sort((a, b) => b.path.compareTo(a.path));
    return files;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<File>>(
      future: _files,
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final files = snap.data!;
        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _files = _load());
            await _files;
          },
          child: files.isEmpty
              ? ListView(children: const [
                  SizedBox(height: 120),
                  Center(child: Text('No exported artwork yet.\nPull down to refresh.',
                      textAlign: TextAlign.center)),
                ])
              : GridView.builder(
                  padding: const EdgeInsets.all(8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, mainAxisSpacing: 8, crossAxisSpacing: 8,
                      childAspectRatio: 0.75),
                  itemCount: files.length,
                  itemBuilder: (_, i) => ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(files[i], fit: BoxFit.cover, cacheWidth: 400),
                  ),
                ),
        );
      },
    );
  }
}
