import 'package:flutter/material.dart';

import 'academy/academy_screen.dart';
import 'canvas/canvas_controller.dart';
import 'canvas/canvas_screen.dart';
import 'community/community_screen.dart';
import 'critic/critic_screen.dart';

/// Bottom navigation: Canvas | Academy | Critic | Community.
/// One CanvasController is shared by all tabs.
class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final controller = CanvasController();
  int tab = 0;

  void _openCanvas() => setState(() => tab = 0);

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final immersive = tab == 0 && controller.zeroUi;
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        final hideNav = tab == 0 && controller.zeroUi;
        return Scaffold(
          body: SafeArea(
            bottom: false,
            child: IndexedStack(index: tab, children: [
              CanvasScreen(controller: controller),
              AcademyScreen(controller: controller, onOpenCanvas: _openCanvas),
              CriticScreen(controller: controller),
              CommunityScreen(controller: controller, onOpenCanvas: _openCanvas),
            ]),
          ),
          bottomNavigationBar: hideNav || immersive
              ? null
              : NavigationBar(
                  selectedIndex: tab,
                  onDestinationSelected: (i) => setState(() => tab = i),
                  destinations: const [
                    NavigationDestination(
                        icon: Icon(Icons.brush_outlined),
                        selectedIcon: Icon(Icons.brush),
                        label: 'Canvas'),
                    NavigationDestination(
                        icon: Icon(Icons.school_outlined),
                        selectedIcon: Icon(Icons.school),
                        label: 'Academy'),
                    NavigationDestination(
                        icon: Icon(Icons.psychology_alt_outlined),
                        selectedIcon: Icon(Icons.psychology_alt),
                        label: 'Critic'),
                    NavigationDestination(
                        icon: Icon(Icons.groups_outlined),
                        selectedIcon: Icon(Icons.groups),
                        label: 'Community'),
                  ],
                ),
        );
      },
    );
  }
}
