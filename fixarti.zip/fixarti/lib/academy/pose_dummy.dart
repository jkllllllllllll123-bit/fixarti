import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Draggable 2D mannequin. Dragging a joint rotates everything beneath it
/// around its parent (bone lengths are preserved). Dragging the hips moves the body.
class PoseDummy extends StatefulWidget {
  const PoseDummy({super.key});

  @override
  State<PoseDummy> createState() => _PoseDummyState();
}

class _PoseDummyState extends State<PoseDummy> {
  static const _initial = <String, Offset>{
    'hips': Offset(160, 270),
    'spine': Offset(160, 210),
    'neck': Offset(160, 152),
    'head': Offset(160, 100),
    'lShoulder': Offset(125, 160),
    'lElbow': Offset(95, 225),
    'lHand': Offset(85, 290),
    'rShoulder': Offset(195, 160),
    'rElbow': Offset(225, 225),
    'rHand': Offset(235, 290),
    'lHip': Offset(140, 275),
    'lKnee': Offset(135, 370),
    'lFoot': Offset(130, 465),
    'rHip': Offset(180, 275),
    'rKnee': Offset(185, 370),
    'rFoot': Offset(190, 465),
  };

  static const _parent = <String, String>{
    'spine': 'hips',
    'neck': 'spine',
    'head': 'neck',
    'lShoulder': 'neck',
    'lElbow': 'lShoulder',
    'lHand': 'lElbow',
    'rShoulder': 'neck',
    'rElbow': 'rShoulder',
    'rHand': 'rElbow',
    'lHip': 'hips',
    'lKnee': 'lHip',
    'lFoot': 'lKnee',
    'rHip': 'hips',
    'rKnee': 'rHip',
    'rFoot': 'rKnee',
  };

  late Map<String, Offset> pos = Map.of(_initial);
  String? _dragging;

  List<String> _subtree(String id) {
    final out = <String>[id];
    for (final e in _parent.entries) {
      if (e.value == id) out.addAll(_subtree(e.key));
    }
    return out;
  }

  String? _hit(Offset p) {
    String? best;
    var bestD = 30.0;
    for (final e in pos.entries) {
      final d = (e.value - p).distance;
      if (d < bestD) {
        bestD = d;
        best = e.key;
      }
    }
    return best;
  }

  void _drag(String id, Offset finger) {
    final parentId = _parent[id];
    if (parentId == null) {
      final d = finger - pos[id]!;
      pos = pos.map((k, v) => MapEntry(k, v + d));
      return;
    }
    final p = pos[parentId]!;
    final len = (_initial[id]! - _initial[parentId]!).distance;
    final dir = finger - p;
    if (dir.distance < 1) return;
    final delta = dir.direction - (pos[id]! - p).direction;
    final cs = math.cos(delta), sn = math.sin(delta);
    for (final j in _subtree(id)) {
      final v = pos[j]! - p;
      pos[j] = p + Offset(v.dx * cs - v.dy * sn, v.dx * sn + v.dy * cs);
    }
    // Re-normalise the dragged bone to its exact length.
    final fix = pos[id]! - p;
    if (fix.distance > 0 && (fix.distance - len).abs() > 0.5) {
      final shift = fix / fix.distance * len - fix;
      for (final j in _subtree(id)) {
        pos[j] = pos[j]! + shift;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: 320,
            height: 520,
            child: GestureDetector(
              onPanStart: (d) => setState(() => _dragging = _hit(d.localPosition)),
              onPanUpdate: (d) {
                final id = _dragging;
                if (id == null) return;
                setState(() => _drag(id, d.localPosition));
              },
              onPanEnd: (_) => _dragging = null,
              child: CustomPaint(painter: _DummyPainter(pos, _dragging)),
            ),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(8),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          OutlinedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text('Reset pose'),
            onPressed: () => setState(() => pos = Map.of(_initial)),
          ),
          const SizedBox(width: 12),
          const Flexible(
              child: Text('Drag the blue handles. Hips move the whole body.',
                  style: TextStyle(fontSize: 12))),
        ]),
      ),
    ]);
  }
}

class _DummyPainter extends CustomPainter {
  _DummyPainter(this.pos, this.active);
  final Map<String, Offset> pos;
  final String? active;

  @override
  void paint(Canvas canvas, Size size) {
    Paint bone(double w) => Paint()
      ..color = const Color(0xFFB8B8C8)
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    void line(String a, String b, double w) =>
        canvas.drawLine(pos[a]!, pos[b]!, bone(w));

    // Torso
    line('hips', 'spine', 38);
    line('spine', 'neck', 34);
    line('lShoulder', 'rShoulder', 18);
    line('lHip', 'rHip', 18);
    // Arms
    line('lShoulder', 'lElbow', 14);
    line('lElbow', 'lHand', 12);
    line('rShoulder', 'rElbow', 14);
    line('rElbow', 'rHand', 12);
    // Legs
    line('lHip', 'lKnee', 18);
    line('lKnee', 'lFoot', 15);
    line('rHip', 'rKnee', 18);
    line('rKnee', 'rFoot', 15);
    // Neck + head
    line('neck', 'head', 10);
    canvas.drawOval(
        Rect.fromCenter(center: pos['head']!, width: 46, height: 56),
        Paint()..color = const Color(0xFFD8D8E8));

    final handle = Paint()..color = const Color(0xFF42A5F5);
    for (final e in pos.entries) {
      canvas.drawCircle(e.value, e.key == active ? 11 : 7, handle);
    }
  }

  @override
  bool shouldRepaint(covariant _DummyPainter old) => true;
}
