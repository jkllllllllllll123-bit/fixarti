import 'package:flutter/material.dart';

import '../canvas/canvas_controller.dart';
import '../canvas/canvas_screen.dart';
import 'pose_dummy.dart';

class AcademyScreen extends StatelessWidget {
  const AcademyScreen({super.key, required this.controller, required this.onOpenCanvas});
  final CanvasController controller;
  final VoidCallback onOpenCanvas;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Column(children: [
        const TabBar(tabs: [
          Tab(icon: Icon(Icons.accessibility_new), text: 'Pose Dummy'),
          Tab(icon: Icon(Icons.menu_book_outlined), text: 'Reference Library'),
        ]),
        Expanded(
          child: TabBarView(
            physics: const NeverScrollableScrollPhysics(), // keep drags for the dummy
            children: [
              const PoseDummy(),
              _Library(controller: controller, onOpenCanvas: onOpenCanvas),
            ],
          ),
        ),
      ]),
    );
  }
}

class _Topic {
  const _Topic(this.title, this.icon, this.tips);
  final String title;
  final IconData icon;
  final List<String> tips;
}

const _topics = <_Topic>[
  _Topic('Eyes', Icons.remove_red_eye_outlined, [
    'Place the eye line about halfway down the head; the gap between the eyes is roughly one eye width.',
    'Draw the upper lash line thicker and darker; it carries most of the eye\'s weight in manga.',
    'Keep both highlights on the same side to show one consistent light source.',
    'In 3/4 view the far eye is narrower - never draw both the same size.',
  ]),
  _Topic('Hands', Icons.back_hand_outlined, [
    'Start with a box for the palm, then add the thumb as a separate wedge.',
    'The palm is about as long as the fingers; the middle finger is the longest.',
    'Fingers bend at three joints and curl toward the palm, not sideways.',
    'Draw hands in simple boxes and cylinders first, details last.',
  ]),
  _Topic('Hair', Icons.face_retouching_natural, [
    'Draw hair as a few big clumps first, not as single strands.',
    'Hair has volume: it sits above the skull line, not on it.',
    'Add a few flowing lines that follow the clump direction, with tapered ends.',
    'Leave highlight bands (white or light tone) following the head curve.',
  ]),
  _Topic('Dynamic Poses', Icons.directions_run, [
    'Begin with one strong line of action running through the spine, head to feet.',
    'Tilt the shoulders and hips in opposite directions (contrapposto) for natural weight.',
    'Overlap limbs and use foreshortening to create depth and impact.',
    'Use the Pose Dummy tab to block the pose before you ink.',
  ]),
];

class _Library extends StatelessWidget {
  const _Library({required this.controller, required this.onOpenCanvas});
  final CanvasController controller;
  final VoidCallback onOpenCanvas;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.add_photo_alternate_outlined),
            title: const Text('Load your own reference'),
            subtitle: const Text('Overlay a photo or pose on your canvas'),
            onTap: () async {
              await CanvasScreen.pickReference(controller);
              onOpenCanvas();
            },
          ),
        ),
        for (final t in _topics)
          Card(
            child: ExpansionTile(
              leading: Icon(t.icon),
              title: Text(t.title),
              children: [
                for (final tip in t.tips)
                  ListTile(
                    dense: true,
                    leading: const Icon(Icons.check_circle_outline, size: 18),
                    title: Text(tip),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
