import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'canvas_controller.dart';
import 'canvas_view.dart';
import 'layer_sheet.dart';
import 'models.dart';

class CanvasScreen extends StatelessWidget {
  const CanvasScreen({super.key, required this.controller});
  final CanvasController controller;

  CanvasController get c => controller;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        return LayoutBuilder(builder: (context, box) {
          final viewport = box.biggest;
          final canvas = Stack(children: [
            Positioned.fill(child: CanvasView(controller: c)),
            if (!c.zeroUi) ...[
              Positioned(top: 0, left: 0, right: 0, child: _topBar(context, viewport)),
              if (c.currentPrompt != null)
                Positioned(
                    top: 52,
                    left: 12,
                    right: 12,
                    child: _promptChip(context)),
              Positioned(left: 0, right: 0, bottom: 0, child: _bottomBar(context)),
            ],
            Positioned(
              right: 8,
              top: c.zeroUi ? 8 : 56,
              child: Opacity(
                opacity: 0.6,
                child: IconButton.filledTonal(
                  tooltip: 'Zero-UI mode',
                  icon: Icon(c.zeroUi ? Icons.fullscreen_exit : Icons.fullscreen),
                  onPressed: c.toggleZeroUi,
                ),
              ),
            ),
          ]);

          if (c.refSplit && c.reference != null) {
            return Column(children: [
              Expanded(flex: 3, child: canvas),
              Expanded(flex: 2, child: _splitReference()),
            ]);
          }
          return canvas;
        });
      },
    );
  }

  // ---------------- top bar ----------------
  Widget _topBar(BuildContext context, Size viewport) {
    return Material(
      color: const Color(0xDD161618),
      child: SizedBox(
        height: 48,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [
            IconButton(
                tooltip: 'Undo (2-finger tap)',
                icon: const Icon(Icons.undo),
                onPressed: c.canUndo ? c.undo : null),
            IconButton(
                tooltip: 'Redo (3-finger tap)',
                icon: const Icon(Icons.redo),
                onPressed: c.canRedo ? c.redo : null),
            IconButton(
                tooltip: 'Mirror',
                icon: const Icon(Icons.flip),
                onPressed: () => c.flipHorizontal(viewport)),
            IconButton(
                tooltip: 'Fit to screen',
                icon: const Icon(Icons.fit_screen),
                onPressed: () => c.fit(viewport)),
            PopupMenuButton<GuideMode>(
              tooltip: 'Guides',
              icon: Icon(Icons.grid_4x4,
                  color: c.guide == GuideMode.none ? null : Colors.lightBlueAccent),
              onSelected: c.setGuide,
              itemBuilder: (_) => const [
                PopupMenuItem(value: GuideMode.none, child: Text('Guides off')),
                PopupMenuItem(value: GuideMode.grid, child: Text('Grid')),
                PopupMenuItem(
                    value: GuideMode.onePoint, child: Text('1-point perspective')),
                PopupMenuItem(
                    value: GuideMode.twoPoint, child: Text('2-point perspective')),
              ],
            ),
            IconButton(
                tooltip: 'Snap strokes to perspective lines',
                icon: Icon(Icons.straighten,
                    color: c.snapToGuide ? Colors.lightBlueAccent : null),
                onPressed: c.toggleSnap),
            IconButton(
                tooltip: 'Layers',
                icon: const Icon(Icons.layers),
                onPressed: () => showLayerSheet(context, c)),
            IconButton(
                tooltip: 'Reference image',
                icon: Icon(Icons.image_outlined,
                    color: c.reference == null ? null : Colors.lightBlueAccent),
                onPressed: () => _referenceSheet(context)),
            IconButton(
                tooltip: 'Export PNG',
                icon: const Icon(Icons.ios_share),
                onPressed: () => _export(context)),
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'clear') c.clearActiveLayer();
                if (v == 'new') c.newCanvas();
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'clear', child: Text('Clear active layer')),
                PopupMenuItem(value: 'new', child: Text('New canvas')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _promptChip(BuildContext context) => Card(
        color: const Color(0xEE3B2A6B),
        child: ListTile(
          dense: true,
          leading: const Icon(Icons.emoji_events_outlined),
          title: Text('Challenge: ${c.currentPrompt}'),
          trailing: IconButton(
              icon: const Icon(Icons.close),
              onPressed: c.clearPrompt),
        ),
      );

  // ---------------- bottom bar ----------------
  static const _palette = <Color>[
    Colors.black,
    Color(0xFF444444),
    Color(0xFF999999),
    Colors.white,
    Color(0xFFD32F2F),
    Color(0xFF1976D2),
    Color(0xFF388E3C),
    Color(0xFF795548),
  ];

  Widget _bottomBar(BuildContext context) {
    return Material(
      color: const Color(0xDD161618),
      child: SafeArea(
        top: false,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 6),
              children: [
                for (final b in BrushType.values)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
                    child: ChoiceChip(
                      avatar: Icon(b.icon, size: 16),
                      label: Text(b.label),
                      selected: c.brush == b,
                      onSelected: (_) => c.setBrush(b),
                    ),
                  ),
                if (c.brush == BrushType.tone)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
                    child: FilterChip(
                      label: Text(c.toneHatch ? 'Hatch' : 'Dots'),
                      selected: c.toneHatch,
                      onSelected: (_) => c.toggleHatch(),
                    ),
                  ),
              ],
            ),
          ),
          Row(children: [
            const SizedBox(width: 12),
            const Icon(Icons.circle, size: 8),
            Expanded(
              child: Slider(
                min: 1,
                max: 60,
                value: c.size,
                onChanged: c.setSize,
              ),
            ),
            const Icon(Icons.circle, size: 20),
            const SizedBox(width: 8),
            for (final col in _palette)
              GestureDetector(
                onTap: () => c.setColor(col),
                child: Container(
                  width: 24,
                  height: 24,
                  margin: const EdgeInsets.only(right: 6),
                  decoration: BoxDecoration(
                    color: col,
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: c.color == col && !c.brush.isEraser
                            ? Colors.lightBlueAccent
                            : Colors.white24,
                        width: c.color == col ? 3 : 1),
                  ),
                ),
              ),
          ]),
        ]),
      ),
    );
  }

  // ---------------- reference ----------------
  Widget _splitReference() => Container(
        color: const Color(0xFF111111),
        child: InteractiveViewer(
          maxScale: 6,
          child: RawImage(image: c.reference, fit: BoxFit.contain),
        ),
      );

  void _referenceSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => ListenableBuilder(
        listenable: c,
        builder: (_, __) => Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            FilledButton.icon(
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('Load reference from gallery'),
              onPressed: () => pickReference(c),
            ),
            if (c.reference != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                const Text('Opacity'),
                Expanded(
                    child: Slider(
                        value: c.refOpacity,
                        min: 0.05,
                        max: 1,
                        onChanged: c.setRefOpacity)),
              ]),
              SwitchListTile(
                  title: const Text('Show above artwork'),
                  value: c.refOnTop,
                  onChanged: (_) => c.toggleRefOnTop()),
              SwitchListTile(
                  title: const Text('Split-screen view'),
                  value: c.refSplit,
                  onChanged: (_) => c.toggleRefSplit()),
              TextButton(
                  onPressed: c.clearReference,
                  child: const Text('Remove reference')),
            ],
          ]),
        ),
      ),
    );
  }

  static Future<void> pickReference(CanvasController c) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x == null) return;
    final bytes = await x.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    c.setReference(frame.image);
  }

  // ---------------- export ----------------
  Future<void> _export(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final bytes = await c.exportPng(scale: 1.0);
      final dir = await getApplicationDocumentsDirectory();
      final gallery = Directory('${dir.path}/fixarti_gallery');
      await gallery.create(recursive: true);
      final file = File(
          '${gallery.path}/fixarti_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(bytes);
      await Share.shareXFiles([XFile(file.path)], text: 'Made with Fixarti');
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Export failed: $e')));
    }
  }
}
