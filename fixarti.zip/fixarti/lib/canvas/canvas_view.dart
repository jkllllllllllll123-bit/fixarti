import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'canvas_controller.dart';
import 'painters.dart';

/// Touch layer: 1 finger draws, 2 fingers pan/zoom/rotate,
/// quick 2-finger tap = undo, quick 3-finger tap = redo.
class CanvasView extends StatefulWidget {
  const CanvasView({super.key, required this.controller});
  final CanvasController controller;

  @override
  State<CanvasView> createState() => _CanvasViewState();
}

class _CanvasViewState extends State<CanvasView> {
  final Map<int, Offset> _pts = {};
  int _maxPointers = 0;
  double _travel = 0;
  bool _drawing = false;
  DateTime _downAt = DateTime.now();
  Size viewport = Size.zero;

  CanvasController get c => widget.controller;

  double? _pressure(PointerEvent e) {
    if (e.kind == PointerDeviceKind.stylus && e.pressureMax > e.pressureMin) {
      return (e.pressure - e.pressureMin) / (e.pressureMax - e.pressureMin);
    }
    return null;
  }

  void _down(PointerDownEvent e) {
    if (_pts.isEmpty) {
      _downAt = DateTime.now();
      _maxPointers = 0;
      _travel = 0;
    }
    _pts[e.pointer] = e.localPosition;
    _maxPointers = math.max(_maxPointers, _pts.length);
    if (_pts.length == 1) {
      _drawing = true;
      c.beginStroke(c.toCanvas(e.localPosition), pressure: _pressure(e));
    } else if (_drawing) {
      c.cancelStroke();
      _drawing = false;
    }
  }

  void _move(PointerMoveEvent e) {
    final prev = _pts[e.pointer];
    if (prev == null) return;

    if (_pts.length == 1) {
      _pts[e.pointer] = e.localPosition;
      if (_drawing) {
        c.addPoint(c.toCanvas(e.localPosition), pressure: _pressure(e));
      }
      return;
    }

    final ids = _pts.keys.take(2).toList();
    final a0 = _pts[ids[0]]!, b0 = _pts[ids[1]]!;
    _pts[e.pointer] = e.localPosition;
    final a1 = _pts[ids[0]]!, b1 = _pts[ids[1]]!;
    _travel += (e.localPosition - prev).distance;

    if (_pts.length == 2 && _maxPointers == 2) {
      final d0 = (b0 - a0).distance, d1 = (b1 - a1).distance;
      if (d0 < 1) return;
      var rot = (b1 - a1).direction - (b0 - a0).direction;
      if (rot > math.pi) rot -= 2 * math.pi;
      if (rot < -math.pi) rot += 2 * math.pi;
      c.applyGesture(
        prevFocal: (a0 + b0) / 2,
        focal: (a1 + b1) / 2,
        scale: d1 / d0,
        rotation: rot,
      );
    }
  }

  void _up(PointerEvent e) {
    _pts.remove(e.pointer);
    if (_drawing && _pts.isEmpty) {
      c.endStroke();
      _drawing = false;
    }
    if (_pts.isEmpty) {
      final ms = DateTime.now().difference(_downAt).inMilliseconds;
      if (ms < 300 && _travel < 16) {
        if (_maxPointers == 2) c.undo();
        if (_maxPointers == 3) c.redo();
      }
      _maxPointers = 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      viewport = box.biggest;
      c.fitIfNeeded(viewport);
      return Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: _down,
        onPointerMove: _move,
        onPointerUp: _up,
        onPointerCancel: _up,
        child: ClipRect(
          child: CustomPaint(
            painter: PagePainter(c),
            size: Size.infinite,
          ),
        ),
      );
    });
  }
}
