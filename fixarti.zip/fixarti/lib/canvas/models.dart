import 'package:flutter/material.dart';

enum BrushType { gPen, maruPen, tone, softEraser, hardEraser }

extension BrushInfo on BrushType {
  String get label => switch (this) {
        BrushType.gPen => 'G-Pen',
        BrushType.maruPen => 'Maru',
        BrushType.tone => 'Tone',
        BrushType.softEraser => 'Soft Eraser',
        BrushType.hardEraser => 'Hard Eraser',
      };

  IconData get icon => switch (this) {
        BrushType.gPen => Icons.edit,
        BrushType.maruPen => Icons.create,
        BrushType.tone => Icons.grain,
        BrushType.softEraser => Icons.blur_on,
        BrushType.hardEraser => Icons.auto_fix_normal,
      };

  bool get isEraser =>
      this == BrushType.softEraser || this == BrushType.hardEraser;
}

enum GuideMode { none, grid, onePoint, twoPoint }

class Stroke {
  Stroke({
    required this.brush,
    required this.color,
    required this.size,
    this.lockAlpha = false,
    this.hatch = false,
  });

  final BrushType brush;
  final Color color;
  final double size;
  final bool lockAlpha;
  final bool hatch;

  final List<Offset> points = [];
  final List<double> widths = [];

  // Screen-tone cache (dots / hatch cells), built incrementally.
  final List<Offset> toneDots = [];
  final Set<int> _cells = {};
  static const double toneSpacing = 6;

  void addPoint(Offset p, double w) {
    points.add(p);
    widths.add(w);
    if (brush == BrushType.tone) _addToneCells(p);
  }

  void _addToneCells(Offset p) {
    final r = size * 0.7;
    final x0 = ((p.dx - r) / toneSpacing).floor();
    final x1 = ((p.dx + r) / toneSpacing).floor();
    final y0 = ((p.dy - r) / toneSpacing).floor();
    final y1 = ((p.dy + r) / toneSpacing).floor();
    for (var gy = y0; gy <= y1; gy++) {
      final shift = gy.isOdd ? toneSpacing / 2 : 0.0;
      for (var gx = x0; gx <= x1; gx++) {
        final c = Offset((gx + 0.5) * toneSpacing + shift,
            (gy + 0.5) * toneSpacing);
        if ((c - p).distance <= r && _cells.add(gx * 100003 + gy)) {
          toneDots.add(c);
        }
      }
    }
  }
}

class Layer {
  Layer(
    this.name, {
    List<Stroke>? strokes,
    this.opacity = 1.0,
    this.visible = true,
    this.alphaLock = false,
  }) : strokes = strokes ?? [];

  String name;
  List<Stroke> strokes;
  double opacity;
  bool visible;
  bool alphaLock;

  Layer copy() => Layer(name,
      strokes: List.of(strokes),
      opacity: opacity,
      visible: visible,
      alphaLock: alphaLock);
}
