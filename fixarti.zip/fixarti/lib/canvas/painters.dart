import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'canvas_controller.dart';
import 'models.dart';

/// Draws strokes and layers. Shared by the on-screen painter and the exporter.
class StrokePainter {
  static void paintLayer(Canvas canvas, Layer layer, Rect bounds) {
    canvas.saveLayer(
        bounds, Paint()..color = Color.fromRGBO(255, 255, 255, layer.opacity));
    for (final s in layer.strokes) {
      paintStroke(canvas, s);
    }
    canvas.restore();
  }

  static void paintStroke(Canvas canvas, Stroke s) {
    if (s.points.isEmpty) return;
    final paint = Paint()
      ..isAntiAlias = true
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = s.color;

    if (s.brush.isEraser) {
      paint.blendMode = BlendMode.clear;
      if (s.brush == BrushType.softEraser) {
        paint.maskFilter = MaskFilter.blur(BlurStyle.normal, s.size * 0.4);
      }
    } else if (s.lockAlpha) {
      // Alpha lock: only paint where the layer already has pixels.
      paint.blendMode = BlendMode.srcATop;
    }

    switch (s.brush) {
      case BrushType.gPen:
        _variableWidth(canvas, s, paint);
      case BrushType.maruPen:
        paint.strokeWidth = (s.size * 0.45).clamp(1.0, 40.0);
        _smoothPath(canvas, s, paint);
      case BrushType.tone:
        _tone(canvas, s, paint);
      case BrushType.softEraser:
        paint.strokeWidth = s.size * 1.8;
        _smoothPath(canvas, s, paint);
      case BrushType.hardEraser:
        paint.strokeWidth = s.size * 1.4;
        _smoothPath(canvas, s, paint);
    }
  }

  static void _variableWidth(Canvas canvas, Stroke s, Paint paint) {
    if (s.points.length == 1) {
      canvas.drawCircle(
          s.points.first, s.widths.first / 2, paint..style = PaintingStyle.fill);
      return;
    }
    for (var i = 1; i < s.points.length; i++) {
      paint.strokeWidth = s.widths[i];
      canvas.drawLine(s.points[i - 1], s.points[i], paint);
    }
  }

  static void _smoothPath(Canvas canvas, Stroke s, Paint paint) {
    final pts = s.points;
    if (pts.length == 1) {
      canvas.drawCircle(
          pts.first, paint.strokeWidth / 2, paint..style = PaintingStyle.fill);
      return;
    }
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 1; i < pts.length - 1; i++) {
      final mid = (pts[i] + pts[i + 1]) / 2;
      path.quadraticBezierTo(pts[i].dx, pts[i].dy, mid.dx, mid.dy);
    }
    path.lineTo(pts.last.dx, pts.last.dy);
    canvas.drawPath(path, paint);
  }

  static void _tone(Canvas canvas, Stroke s, Paint paint) {
    if (s.toneDots.isEmpty) return;
    if (!s.hatch) {
      paint.strokeWidth = 2.4;
      canvas.drawPoints(ui.PointMode.points, s.toneDots, paint);
    } else {
      paint.strokeWidth = 1.2;
      final path = Path();
      const h = Stroke.toneSpacing * 0.5;
      for (final c in s.toneDots) {
        path.moveTo(c.dx - h, c.dy + h);
        path.lineTo(c.dx + h, c.dy - h);
      }
      canvas.drawPath(path, paint);
    }
  }
}

/// On-screen painter: paper, reference, layers and guides, under the view matrix.
class PagePainter extends CustomPainter {
  PagePainter(this.c) : super(repaint: c);
  final CanvasController c;

  @override
  void paint(Canvas canvas, Size size) {
    final page = Offset.zero & CanvasController.pageSize;
    canvas.save();
    canvas.transform(c.view.storage);

    canvas.drawRect(
        page.inflate(4), Paint()..color = const Color(0x55000000));
    canvas.drawRect(page, Paint()..color = Colors.white);
    canvas.clipRect(page);

    if (c.reference != null && !c.refOnTop) _drawReference(canvas, page);
    for (final layer in c.layers) {
      if (layer.visible) StrokePainter.paintLayer(canvas, layer, page);
    }
    if (c.reference != null && c.refOnTop) _drawReference(canvas, page);
    _drawGuides(canvas, page);

    canvas.restore();
  }

  void _drawReference(Canvas canvas, Rect page) {
    final img = c.reference!;
    final src = Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble());
    final fitted = applyBoxFit(BoxFit.contain, src.size, page.size);
    final dst = Alignment.center.inscribe(fitted.destination, page);
    canvas.drawImageRect(img, src, dst,
        Paint()..color = Color.fromRGBO(255, 255, 255, c.refOpacity));
  }

  void _drawGuides(Canvas canvas, Rect page) {
    if (c.guide == GuideMode.none) return;
    final p = Paint()
      ..color = const Color(0x552196F3)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    if (c.guide == GuideMode.grid) {
      for (var x = 0.0; x <= page.width; x += 100) {
        canvas.drawLine(Offset(x, 0), Offset(x, page.height), p);
      }
      for (var y = 0.0; y <= page.height; y += 100) {
        canvas.drawLine(Offset(0, y), Offset(page.width, y), p);
      }
      return;
    }

    // Horizon + rays from each vanishing point.
    final horizon = page.height / 2;
    canvas.drawLine(
        Offset(0, horizon),
        Offset(page.width, horizon),
        p..color = const Color(0x99FF9800));
    p.color = const Color(0x552196F3);
    for (final vp in c.vanishingPoints()) {
      for (var a = 0; a < 360; a += 10) {
        final dir = Offset.fromDirection(a * 3.14159265 / 180);
        canvas.drawLine(vp, vp + dir * 3000, p);
      }
      canvas.drawCircle(vp, 8, Paint()..color = const Color(0xFFFF9800));
    }
  }

  @override
  bool shouldRepaint(covariant PagePainter old) => true;
}
