import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'models.dart';
import 'painters.dart';

class _Snap {
  _Snap(this.layers, this.active);
  final List<Layer> layers;
  final int active;
}

/// All drawing state: layers, brushes, undo/redo, view transform, guides.
class CanvasController extends ChangeNotifier {
  static const Size pageSize = Size(1200, 1600);

  // ---- document ----
  List<Layer> layers = [Layer('Layer 1'), Layer('Layer 2'), Layer('Layer 3')];
  int active = 0;

  // ---- tool state ----
  BrushType brush = BrushType.gPen;
  Color color = Colors.black;
  double size = 6;
  bool toneHatch = false;

  // ---- view ----
  Matrix4 view = Matrix4.identity();
  bool _fitted = false;
  bool zeroUi = false;

  // ---- guides ----
  GuideMode guide = GuideMode.none;
  bool snapToGuide = false;

  // ---- reference overlay ----
  ui.Image? reference;
  double refOpacity = 0.4;
  bool refOnTop = true;
  bool refSplit = false;

  // ---- challenge ----
  String? currentPrompt;

  // ---- undo / redo ----
  final List<_Snap> _undo = [];
  final List<_Snap> _redo = [];
  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;

  Stroke? _current;
  Offset? _snapOrigin;
  Offset? _snapDir;

  Layer get activeLayer => layers[active];

  // ================= tools =================
  void setBrush(BrushType b) {
    brush = b;
    notifyListeners();
  }

  void setColor(Color c) {
    color = c;
    if (brush.isEraser) brush = BrushType.gPen;
    notifyListeners();
  }

  void setSize(double s) {
    size = s;
    notifyListeners();
  }

  void toggleHatch() {
    toneHatch = !toneHatch;
    notifyListeners();
  }

  void toggleZeroUi() {
    zeroUi = !zeroUi;
    notifyListeners();
  }

  void setGuide(GuideMode g) {
    guide = g;
    notifyListeners();
  }

  void toggleSnap() {
    snapToGuide = !snapToGuide;
    notifyListeners();
  }

  // ================= undo / redo =================
  _Snap _snap() => _Snap(layers.map((l) => l.copy()).toList(), active);

  void _pushUndo() {
    _undo.add(_snap());
    if (_undo.length > 60) _undo.removeAt(0);
    _redo.clear();
  }

  void _restore(_Snap s) {
    layers = s.layers;
    active = s.active.clamp(0, layers.length - 1);
  }

  void undo() {
    if (_undo.isEmpty) return;
    _redo.add(_snap());
    _restore(_undo.removeLast());
    notifyListeners();
  }

  void redo() {
    if (_redo.isEmpty) return;
    _undo.add(_snap());
    _restore(_redo.removeLast());
    notifyListeners();
  }

  // ================= drawing =================
  List<Offset> vanishingPoints() {
    final h = pageSize.height / 2;
    switch (guide) {
      case GuideMode.onePoint:
        return [Offset(pageSize.width / 2, h)];
      case GuideMode.twoPoint:
        return [Offset(-pageSize.width / 2, h), Offset(pageSize.width * 1.5, h)];
      default:
        return const [];
    }
  }

  void beginStroke(Offset p, {double? pressure}) {
    final layer = activeLayer;
    if (!layer.visible) return;
    _pushUndo();
    final s = Stroke(
      brush: brush,
      color: color,
      size: size,
      lockAlpha: layer.alphaLock,
      hatch: toneHatch,
    );
    _current = s;
    layer.strokes.add(s);

    // Ruler-style perspective snapping: lock the stroke to the line
    // through the nearest vanishing point and the starting point.
    _snapOrigin = null;
    _snapDir = null;
    final vps = vanishingPoints();
    if (snapToGuide && vps.isNotEmpty && !brush.isEraser) {
      var best = vps.first;
      for (final vp in vps) {
        if ((vp - p).distance < (best - p).distance) best = vp;
      }
      final d = p - best;
      if (d.distance > 1) {
        _snapOrigin = p;
        _snapDir = d / d.distance;
      }
    }
    addPoint(p, pressure: pressure);
  }

  Offset _applySnap(Offset p) {
    final o = _snapOrigin, d = _snapDir;
    if (o == null || d == null) return p;
    final t = (p - o).dx * d.dx + (p - o).dy * d.dy;
    return o + d * t;
  }

  void addPoint(Offset raw, {double? pressure}) {
    final s = _current;
    if (s == null) return;
    final p = _applySnap(raw);
    if (s.points.isNotEmpty && (p - s.points.last).distance < 0.6) return;

    var w = s.size;
    if (s.brush == BrushType.gPen) {
      double target;
      if (pressure != null) {
        target = 0.3 + pressure.clamp(0.0, 1.0) * 0.9;
      } else {
        final dist = s.points.isEmpty ? 0.0 : (p - s.points.last).distance;
        target = (1.15 - dist * 0.03).clamp(0.35, 1.1);
      }
      final prev = s.widths.isEmpty ? target * s.size : s.widths.last;
      w = prev * 0.7 + target * s.size * 0.3;
    }
    s.addPoint(p, w);
    notifyListeners();
  }

  void endStroke() {
    _current = null;
    _snapOrigin = null;
    _snapDir = null;
    notifyListeners();
  }

  /// Called when a second finger lands: the in-progress stroke was really a gesture.
  void cancelStroke() {
    final s = _current;
    if (s == null) return;
    activeLayer.strokes.remove(s);
    if (_undo.isNotEmpty) _undo.removeLast();
    _current = null;
    notifyListeners();
  }

  // ================= layers =================
  void selectLayer(int i) {
    active = i;
    notifyListeners();
  }

  void addLayer() {
    _pushUndo();
    layers.insert(active + 1, Layer('Layer ${layers.length + 1}'));
    active += 1;
    notifyListeners();
  }

  void deleteLayer(int i) {
    if (layers.length <= 1) return;
    _pushUndo();
    layers.removeAt(i);
    active = active.clamp(0, layers.length - 1);
    notifyListeners();
  }

  void moveLayer(int from, int to) {
    _pushUndo();
    final l = layers.removeAt(from);
    layers.insert(to, l);
    active = to;
    notifyListeners();
  }

  void setOpacity(int i, double v) {
    layers[i].opacity = v;
    notifyListeners();
  }

  void toggleVisible(int i) {
    layers[i].visible = !layers[i].visible;
    notifyListeners();
  }

  void toggleAlphaLock(int i) {
    layers[i].alphaLock = !layers[i].alphaLock;
    notifyListeners();
  }

  void clearActiveLayer() {
    _pushUndo();
    activeLayer.strokes = [];
    notifyListeners();
  }

  void clearPrompt() {
    currentPrompt = null;
    notifyListeners();
  }

  void newCanvas({String? prompt}) {
    layers = [Layer('Layer 1'), Layer('Layer 2'), Layer('Layer 3')];
    active = 0;
    _undo.clear();
    _redo.clear();
    currentPrompt = prompt;
    notifyListeners();
  }

  // ================= view transform =================
  void fitIfNeeded(Size viewport) {
    if (_fitted || viewport.isEmpty) return;
    _fitted = true;
    fit(viewport, notify: false);
  }

  void fit(Size viewport, {bool notify = true}) {
    final s = (viewport.width / pageSize.width <
                viewport.height / pageSize.height
            ? viewport.width / pageSize.width
            : viewport.height / pageSize.height) *
        0.95;
    final dx = (viewport.width - pageSize.width * s) / 2;
    final dy = (viewport.height - pageSize.height * s) / 2;
    view = Matrix4.identity()
      ..translate(dx, dy, 0.0)
      ..scale(s, s, 1.0);
    if (notify) notifyListeners();
  }

  void applyGesture({
    required Offset prevFocal,
    required Offset focal,
    required double scale,
    required double rotation,
  }) {
    final m = Matrix4.identity()
      ..translate(focal.dx, focal.dy, 0.0)
      ..rotateZ(rotation)
      ..scale(scale, scale, 1.0)
      ..translate(-prevFocal.dx, -prevFocal.dy, 0.0);
    view = m.multiplied(view);
    notifyListeners();
  }

  /// Instant horizontal mirror of the view (great for checking proportions).
  void flipHorizontal(Size viewport) {
    final cx = viewport.width / 2;
    final m = Matrix4.identity()
      ..translate(cx, 0.0, 0.0)
      ..scale(-1.0, 1.0, 1.0)
      ..translate(-cx, 0.0, 0.0);
    view = m.multiplied(view);
    notifyListeners();
  }

  Offset toCanvas(Offset screen) {
    final inv = Matrix4.tryInvert(view);
    if (inv == null) return screen;
    return MatrixUtils.transformPoint(inv, screen);
  }

  // ================= reference =================
  void setReference(ui.Image img) {
    reference = img;
    notifyListeners();
  }

  void clearReference() {
    reference = null;
    refSplit = false;
    notifyListeners();
  }

  void setRefOpacity(double v) {
    refOpacity = v;
    notifyListeners();
  }

  void toggleRefOnTop() {
    refOnTop = !refOnTop;
    notifyListeners();
  }

  void toggleRefSplit() {
    refSplit = !refSplit;
    notifyListeners();
  }

  // ================= export =================
  /// Renders the artwork. [onlyActiveLayer] is used by the AI critic.
  Future<ui.Image> renderImage(
      {double scale = 1.0, bool onlyActiveLayer = false}) {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.scale(scale);
    final rect = Offset.zero & pageSize;
    canvas.drawRect(rect, Paint()..color = Colors.white);
    for (var i = 0; i < layers.length; i++) {
      if (onlyActiveLayer && i != active) continue;
      if (!layers[i].visible) continue;
      StrokePainter.paintLayer(canvas, layers[i], rect);
    }
    return recorder.endRecording().toImage(
        (pageSize.width * scale).round(), (pageSize.height * scale).round());
  }

  Future<Uint8List> exportPng(
      {double scale = 1.0, bool onlyActiveLayer = false}) async {
    final img =
        await renderImage(scale: scale, onlyActiveLayer: onlyActiveLayer);
    final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
    return bytes!.buffer.asUint8List();
  }
}
