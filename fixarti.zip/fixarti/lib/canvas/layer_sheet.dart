import 'package:flutter/material.dart';

import 'canvas_controller.dart';

void showLayerSheet(BuildContext context, CanvasController c) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final n = c.layers.length;
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.7),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                title: const Text('Layers'),
                trailing: FilledButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Add'),
                  onPressed: c.addLayer,
                ),
              ),
              Flexible(
                // Top of the list = top layer. UI index u maps to layer n-1-u.
                child: ReorderableListView.builder(
                  shrinkWrap: true,
                  itemCount: n,
                  onReorder: (oldU, newU) {
                    if (newU > oldU) newU -= 1;
                    c.moveLayer(n - 1 - oldU, n - 1 - newU);
                  },
                  itemBuilder: (context, u) {
                    final i = n - 1 - u;
                    final l = c.layers[i];
                    return Card(
                      key: ObjectKey(l),
                      color: i == c.active ? const Color(0xFF3B2A6B) : null,
                      child: ListTile(
                        onTap: () => c.selectLayer(i),
                        leading: IconButton(
                          icon: Icon(
                              l.visible ? Icons.visibility : Icons.visibility_off),
                          onPressed: () => c.toggleVisible(i),
                        ),
                        title: Text(l.name),
                        subtitle: Slider(
                          value: l.opacity,
                          onChanged: (v) => c.setOpacity(i, v),
                        ),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            tooltip: 'Alpha lock (clip to existing pixels)',
                            icon: Icon(l.alphaLock ? Icons.lock : Icons.lock_open,
                                color: l.alphaLock ? Colors.amber : null),
                            onPressed: () => c.toggleAlphaLock(i),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: n > 1 ? () => c.deleteLayer(i) : null,
                          ),
                        ]),
                      ),
                    );
                  },
                ),
              ),
            ]),
          ),
        );
      },
    ),
  );
}
