import 'package:flutter/material.dart';

import '../canvas/canvas_controller.dart';
import 'critic_service.dart';

class CriticScreen extends StatefulWidget {
  const CriticScreen({super.key, required this.controller});
  final CanvasController controller;

  @override
  State<CriticScreen> createState() => _CriticScreenState();
}

class _CriticScreenState extends State<CriticScreen> {
  final _keyCtl = TextEditingController();
  final _service = ArtCriticService();
  bool _consented = false;
  bool _activeLayerOnly = false;
  bool _arabic = false;
  bool _loading = false;
  String? _error;
  CritiqueResult? _result;

  static const _privacy =
      'Fixarti never stores your artwork on a server and never uses it for AI training. '
      'A snapshot is sent ONLY when you tap "Ask Art Critic", directly to the AI provider '
      'you configured, and the AI only writes feedback - it never changes your drawing. '
      'Please also check your AI provider\'s own data policy.';

  Future<bool> _ensureConsent() async {
    if (_consented) return true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.privacy_tip_outlined),
        title: const Text('Your art stays yours'),
        content: const Text(_privacy),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('I understand')),
        ],
      ),
    );
    _consented = ok == true;
    return _consented;
  }

  Future<void> _ask() async {
    final key = _keyCtl.text.trim();
    if (key.isEmpty) {
      setState(() => _error = 'Enter your API key first.');
      return;
    }
    if (!await _ensureConsent()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      // Half-size snapshot keeps the upload small and fast.
      final png = await widget.controller
          .exportPng(scale: 0.5, onlyActiveLayer: _activeLayerOnly);
      final r = await _service.review(
        png: png,
        apiKey: key,
        language: _arabic ? 'Arabic' : 'English',
      );
      setState(() => _result = r);
    } catch (e) {
      setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _keyCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        color: const Color(0xFF1F2A44),
        child: const Padding(
          padding: EdgeInsets.all(12),
          child: Row(children: [
            Icon(Icons.lock_outline),
            SizedBox(width: 10),
            Expanded(
                child: Text(
                    'Optional. The critic only comments - it never draws on your art, '
                    'and nothing is sent until you tap the button.')),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _keyCtl,
        obscureText: true,
        decoration: const InputDecoration(
            labelText: 'AI API key', border: OutlineInputBorder()),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Review active layer only'),
        value: _activeLayerOnly,
        onChanged: (v) => setState(() => _activeLayerOnly = v),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Feedback in Arabic'),
        value: _arabic,
        onChanged: (v) => setState(() => _arabic = v),
      ),
      FilledButton.icon(
        onPressed: _loading ? null : _ask,
        icon: _loading
            ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.psychology_alt_outlined),
        label: const Text('Ask Art Critic'),
      ),
      if (_error != null)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(_error!, style: const TextStyle(color: Colors.redAccent)),
        ),
      if (_result != null) ..._resultCards(_result!),
    ]);
  }

  List<Widget> _resultCards(CritiqueResult r) => [
        const SizedBox(height: 16),
        if (r.summary.isNotEmpty)
          Card(child: Padding(padding: const EdgeInsets.all(12), child: Text(r.summary))),
        for (final s in r.sections)
          Card(
            child: ListTile(
              title: Text('${s.title}${s.score != null ? '  -  ${s.score}/10' : ''}'),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('${s.feedback}\n\nTip: ${s.tip}'),
              ),
            ),
          ),
      ];
}
