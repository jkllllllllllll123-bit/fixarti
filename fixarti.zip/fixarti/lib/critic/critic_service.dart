import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

class CritiqueSection {
  CritiqueSection(this.title, this.score, this.feedback, this.tip);
  final String title;
  final int? score;
  final String feedback;
  final String tip;
}

class CritiqueResult {
  CritiqueResult({required this.summary, required this.sections, this.raw});
  final String summary;
  final List<CritiqueSection> sections;
  final String? raw; // set if the reply was not valid JSON
}

/// Optional AI reviewer. It only READS a snapshot of the canvas and returns
/// text. It never modifies or draws on the artwork.
///
/// NOTE: calling the API directly from the app means the key lives on the
/// device. For a public release, route this through your own backend.
class ArtCriticService {
  static const endpoint = 'https://api.anthropic.com/v1/messages';
  static const model = 'claude-sonnet-5-5';

  static String systemPrompt(String language) => '''
You are a kind, honest manga and digital-art mentor reviewing a beginner-to-intermediate artist's work.
Never offer to redraw or fix the artwork yourself; teach the artist what to improve.
Evaluate exactly three areas: anatomy, line_confidence, composition.
Reply in $language. Output ONLY valid JSON with this shape:
{"summary": string,
 "anatomy": {"score": 1-10, "feedback": string, "tip": string},
 "line_confidence": {"score": 1-10, "feedback": string, "tip": string},
 "composition": {"score": 1-10, "feedback": string, "tip": string}}
If the canvas is blank or too rough to judge, say so politely in "summary" and use null scores.
''';

  Future<CritiqueResult> review({
    required Uint8List png,
    required String apiKey,
    String language = 'English',
  }) async {
    final res = await http
        .post(
          Uri.parse(endpoint),
          headers: {
            'content-type': 'application/json',
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01',
          },
          body: jsonEncode({
            'model': model,
            'max_tokens': 1024,
            'system': systemPrompt(language),
            'messages': [
              {
                'role': 'user',
                'content': [
                  {
                    'type': 'image',
                    'source': {
                      'type': 'base64',
                      'media_type': 'image/png',
                      'data': base64Encode(png),
                    },
                  },
                  {'type': 'text', 'text': 'Please review my drawing.'},
                ],
              }
            ],
          }),
        )
        .timeout(const Duration(seconds: 60));

    if (res.statusCode != 200) {
      throw Exception('API error ${res.statusCode}: ${res.body}');
    }
    final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final text = (body['content'] as List)
        .where((b) => b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join();
    return _parse(text);
  }

  CritiqueResult _parse(String text) {
    try {
      final start = text.indexOf('{');
      final end = text.lastIndexOf('}');
      final j = jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
      CritiqueSection sec(String key, String title) {
        final m = (j[key] ?? {}) as Map<String, dynamic>;
        return CritiqueSection(
          title,
          (m['score'] as num?)?.toInt(),
          '${m['feedback'] ?? ''}',
          '${m['tip'] ?? ''}',
        );
      }

      return CritiqueResult(
        summary: '${j['summary'] ?? ''}',
        sections: [
          sec('anatomy', 'Anatomy'),
          sec('line_confidence', 'Line Confidence'),
          sec('composition', 'Composition'),
        ],
      );
    } catch (_) {
      return CritiqueResult(summary: text, sections: const [], raw: text);
    }
  }
}
